Author: MIDN Tristen Alvis (260102)
Description: SI444 Project (Fitness App)

Notes:
- I met all requirements laid out in my proposal except adding check boxes to the workout activity 
view to help track progress. 
