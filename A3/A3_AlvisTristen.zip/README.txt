Name: MIDN Tristen Alvis
Alpha: 260102
Description: All project requirements were met. For extensions, I chose to implement a "delete some" option in the options menu. 