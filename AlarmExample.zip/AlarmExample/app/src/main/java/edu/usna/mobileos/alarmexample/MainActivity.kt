package edu.usna.mobileos.alarmexample

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private lateinit var alarmManager: AlarmManager
    private lateinit var pendingIntent: PendingIntent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Initialize alarm manager
        val alarmManager = baseContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

        //Create intent for action Alarm triggers
        val alarmIntent = Intent(baseContext, AlarmReceiver::class.java)

        //Pass intent as parameter to PendingIntent to allow predefined code to run
        pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, PendingIntent.FLAG_IMMUTABLE)

        //Set alarm to fire at given time (one minute from now)
        //alarmManager?.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 60 * 1000, pendingIntent)


        //Cancel Alarm
        //alarmManager?.cancel(pendingIntent)

        //Register Buttons
        val setButton: Button = findViewById(R.id.startButton)
        val cancelButton: Button = findViewById(R.id.stopButton)

        //Set click listener
        setButton.setOnClickListener {
            alarmManager?.set(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 5_000,
                pendingIntent
            )
        }
        cancelButton.setOnClickListener {
            alarmManager?.cancel(pendingIntent)
        }
    }
}